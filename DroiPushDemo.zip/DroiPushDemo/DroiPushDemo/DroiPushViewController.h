//
//  DroiPushViewController.h
//  DroiPushDemo
//
//  Created by Jon on 16/7/13.
//  Copyright © 2016年 Droi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DroiPushViewController : UIViewController

- (void)LogString:(NSString *)string;

@end
